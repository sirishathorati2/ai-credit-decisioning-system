
const express = require("express");
const router = express.Router();

function scoreApplicant(a){
  const tenureScore = Math.min(100,(a.tenure/24)*100);
  const overdraftScore = Math.max(0,100 - a.overdraft*15);
  const ratioScore = Math.max(0,Math.min(100,(a.income/a.requested)*60));

  const score =
    a.consistency*0.30 +
    a.punctuality*0.25 +
    tenureScore*0.20 +
    overdraftScore*0.15 +
    ratioScore*0.10;

  return Math.round(score);
}

router.post("/",(req,res)=>{
  const score=scoreApplicant(req.body);

  let decision =
    score>=75?"Approved":
    score>=55?"Reduced Limit":
    score>=40?"Manual Review":
    "Declined";

  res.json({score,decision});
});

module.exports = router;
