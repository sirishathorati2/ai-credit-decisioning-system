
const mongoose = require("mongoose");
const DecisionSchema = new mongoose.Schema({
 applicant:Object,
 score:Number,
 decision:String,
 createdAt:{type:Date,default:Date.now}
});
module.exports = mongoose.model("Decision",DecisionSchema);
