
const express = require("express");
const cors = require("cors");
const mongoose = require("mongoose");
const dotenv = require("dotenv");

dotenv.config();

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGO_URL)
  .then(()=>console.log("MongoDB connected"))
  .catch(err=>console.log(err));

function scoreApplicant(a){
  const tenureScore = Math.min(100,(a.tenure/24)*100);
  const overdraftScore = Math.max(0,100 - a.overdraft*15);
  const ratioScore = Math.max(0,Math.min(100,(a.income/a.requested)*60));

  const score =
    a.consistency*0.30 +
    a.punctuality*0.25 +
    tenureScore*0.20 +
    overdraftScore*0.15 +
    ratioScore*0.10;

  return Math.round(score);
}

app.post("/score",(req,res)=>{
  const a=req.body;
  const score=scoreApplicant(a);

  let decision =
    score>=75?"Approved":
    score>=55?"Reduced Limit":
    score>=40?"Manual Review":
    "Declined";

  res.json({score,decision});
});

app.listen(3000,()=>console.log("Server running"));
