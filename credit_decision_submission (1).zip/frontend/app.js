
async function score(){
const data={
income:+income.value,
consistency:+consistency.value,
punctuality:+punctuality.value,
tenure:+tenure.value,
overdraft:+overdraft.value,
requested:+requested.value
};

const res=await fetch("http://localhost:3000/score",{
method:"POST",
headers:{"Content-Type":"application/json"},
body:JSON.stringify(data)
});

const out=await res.json();
document.getElementById("out").innerText=
"Score: "+out.score+" Decision: "+out.decision;
}
