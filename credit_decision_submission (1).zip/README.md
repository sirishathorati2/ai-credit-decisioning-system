
# Credit Decision System

## Run Backend
npm install
node server.js

## Features
- Credit scoring engine
- API-based decisioning
- Simple frontend UI
